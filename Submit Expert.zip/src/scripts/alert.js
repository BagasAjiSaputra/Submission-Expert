export function initializeNavbarAlerts() {
    document.addEventListener("DOMContentLoaded", function () {
        const navbarLinks = document.querySelectorAll('a');

        navbarLinks.forEach(link => {
            link.addEventListener('click', function (event) {
                event.preventDefault(); 
                Swal.fire({
                    title: 'Under Development',
                    text: 'This feature is currently under development.',
                    icon: 'info',
                    confirmButtonText: 'OK',
                });
            });
        });
    });
}