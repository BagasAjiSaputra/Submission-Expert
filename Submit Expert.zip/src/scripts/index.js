
import { initNavbar } from './navbar.js';
import { initLoad } from './load.js';
// import { initializeNavbarAlerts } from './alert.js';
import { displayRestaurants } from './data.js'; 

// initializeNavbarAlerts();
initNavbar();
initLoad();

window.onload = () => {
    displayRestaurants('restaurant-container');
};

console.log('Webpack Running! :)');
