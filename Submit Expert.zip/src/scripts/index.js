import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';

console.log('Hello Coders! :)');

document.addEventListener("DOMContentLoaded", function () {
    const hamburg = document.getElementById("hambur");
    const menu = document.getElementById("navbar");
  
    // Set tampilan default untuk menu
    menu.style.display = "none"; // Sembunyikan navbar secara default
  
    hamburg.addEventListener("click", function (event) {
      event.preventDefault();
  
      // Cek apakah navbar saat ini ditampilkan
      if (menu.style.display === "flex") {
        menu.style.display = "none"; // Sembunyikan navbar
      } else {
        menu.style.display = "flex"; // Tampilkan navbar
      }
    });
  });
  
  