import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import { initNavbar } from './navbar.js';
import { initLoad } from './load.js';

initNavbar();
initLoad();


console.log('Hello Coders! :)');

