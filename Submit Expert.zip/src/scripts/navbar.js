export function initNavbar() {
    document.addEventListener("DOMContentLoaded", function () {
      const hamburg = document.querySelector(".hambur");
      const menu = document.querySelector(".navbar");
  
      hamburg.addEventListener("click", function (event) {
        event.preventDefault();
        if (menu.style.display === "flex") {
          menu.style.transition = "all 0.5s ease";
          menu.style.transform = "translateY(-5%)";
          menu.style.opacity = "0";
  
          setTimeout(() => {
            menu.style.display = "none";
          }, 300);
        } else {
          menu.style.display = "flex";
          menu.style.transition = "none";
          menu.style.transform = "translateY(-5%)";
          menu.style.opacity = "0";
  
          setTimeout(() => {
            menu.style.transition = "all 0.5s ease";
            menu.style.transform = "translateY(0)";
            menu.style.opacity = "1";
          }, 10);
        }
      });
    });
  }
  