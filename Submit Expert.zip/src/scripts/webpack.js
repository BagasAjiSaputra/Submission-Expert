import 'regenerator-runtime'; 
import '../styles/main.css';